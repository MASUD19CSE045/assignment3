<div class="clear">
        </div>
    </div>
    <div class="clear">
    </div>
    <div id="site_info">
        <p>
         &copy; Copyright E-Learning. All Rights Reserved.
        </p>
    </div>
</body>
</html>
